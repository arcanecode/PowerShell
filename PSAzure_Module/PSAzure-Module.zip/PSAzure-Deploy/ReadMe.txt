This folder has code for deploying the module to the users Documents WindowsPowerShell folder.

DeployModule.ps1 has functions to aid in deploying modules.

Install-PSAzureModule.ps1 has the code for actually deploying the module. Be sure to update the variables in it for the folder you are deploying from.