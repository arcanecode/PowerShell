This folder contains examples the demonstrate the use of the PSAzure module.

Create-ProfileContext.ps1 demonstrates how to create a context profile you can use to make login easy.

Get-AzureVMOptions.ps1 shows how to get the textual values needed to create a virual machine image, as well as determine the size of a virtual machine.

The Create, Start, Stop, and Remove AzureVM scripts demonstrate how to use PSAzure to work with Azure virtual machines.