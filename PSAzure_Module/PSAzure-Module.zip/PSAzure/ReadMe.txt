This folder contains the module itself.

Sapien PowerShell Studio was used to create the module, the psproj and psprojs files are part of their code. If you are not using PowerShell Studio you can ignore these two files.

While all of the files have documentation in the form of inline comment help, not all of them (as of this writing) have examples in the PSAzure-Examples folder.