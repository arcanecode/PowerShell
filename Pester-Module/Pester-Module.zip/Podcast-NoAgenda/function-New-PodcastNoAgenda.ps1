﻿function New-PodcastNoAgenda
{
  return [PodcastNoAgenda]::new()
}